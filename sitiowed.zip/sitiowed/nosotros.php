<?php include ("template/cabecera.php");?>

<div class="jumbotron">
    <h1 class="display-3">Nosotros</h1>
    <p class="lead">hola somos un grupo de personas </p>
    <hr class="my-2">
</div>

<?php include("template/pie.php");?>
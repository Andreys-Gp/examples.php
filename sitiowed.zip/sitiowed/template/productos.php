<?php include ("template/cabecera.php");?>

<div class="col-md-3">

<div class="card">

    <img class="card-img-top" src="holder.js/100x180/" alt="">

    <div class="card-body">
        <h4 class="card-title">Title</h4>
        <p class="card-text">Text</p>
</div>

</div>

</div>
<div class="card">

    <img class="card-img-top" src="holder.js/100x180/" alt="">

    <div class="card-body">
        <h4 class="card-title">Title</h4>
        <p class="card-text">Text</p>
</div>

</div>

</div>
<div class="card">

    <img class="card-img-top" src="holder.js/100x180/" alt="">

    <div class="card-body">
        <h4 class="card-title">Title</h4>
        <p class="card-text">Text</p>
</div>

</div>

</div>
<div class="card">

    <img class="card-img-top" src="holder.js/100x180/" alt="">

    <div class="card-body">
        <h4 class="card-title">Title</h4>
        <p class="card-text">Text</p>
</div>

</div>

</div>



<?php include("template/pie.php");?>
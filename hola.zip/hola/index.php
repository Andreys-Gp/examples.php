
<?php include("template/cabecera.php");?>

<div class="jumbotron text-center">
	<h1 class ="display-3">Bienvenidos al sitio web de Libros</h1>
	<p class="lead">Consulta libros de Programacion</p>
	<hr class="my-2">

	<img width="600"src="img/fondo.jpg" class="img-thumbnail rounded mx-auto d-block"/>
	<p>Mas Informacion</p>
	<p class="lead">
		<a class="btn btn-primary btn-lg" href="productos.php" role="button">Ver almacen de Libros</a>
	</p>
</div>
<?php include ("template/pie.php"); 
?>			

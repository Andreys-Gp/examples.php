<?php include("template/cabecera.php");?>

<div class="jumbotron">
	<h1 class ="display-3">Nosotros</h1>
	<p class="lead">Hola somos un grupo de personas que se dedican al desarrollo web</p>
	<hr class="my-2">
	
</div>


<?php include ("template/pie.php");?>			
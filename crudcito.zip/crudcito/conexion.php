<?php

$dbname="escuela";
$dbuser="root";
$dbhost="localhost";
$dbpass= "";

$conexion=mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
?>